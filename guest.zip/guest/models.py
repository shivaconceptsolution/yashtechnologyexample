from django.db import models

class Fupload(models.Model):
	filepath = models.CharField(max_length=100)

class Student(models.Model):
    rno = models.CharField(max_length=50)
    sname = models.CharField(max_length=50)