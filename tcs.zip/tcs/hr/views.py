from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    return render(request,"hr/index.html")

def about(request):
    return render(request,"hr/about.html")

def contact(request):
    return render(request,"hr/contact.html")    
      