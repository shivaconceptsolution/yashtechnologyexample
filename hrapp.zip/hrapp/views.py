from django.shortcuts import render,redirect
from .models import Reg
from django.http import HttpResponse

def index(request):
    if request.method=="POST":
        obj = Reg(username=request.POST["txtuser"],password=request.POST["txtpass"],role=request.POST["txtrole"],fname=request.POST["txtfname"])

        obj.save()
        return render(request,"hrapp/index.html",{"key":'reg successfully'})
    return render(request,"hrapp/index.html")

def loginlogic(request):
     obj = Reg.objects.filter(username=request.POST["txtu"],password=request.POST['txtp'])
     if obj.count()>0:
        request.session['uid']=request.POST["txtu"]
        return redirect('dashboard')
     else:
         return HttpResponse("Login not successfully")   
def about(request):
	return render(request,"hrapp/about.html")

def contact(request):
	return render(request,"hrapp/contact.html")

def dashboard(request):
     res = Reg.objects.filter(username=request.session['uid'])
     return render(request,"hrapp/dashboard.html",{'data':res,'data1':request.session['uid']})

def findrec(request):
     s = Reg.objects.get(pk=request.GET["q"])
     return render(request,"hrapp/findrec.html",{'data':s})

def updaterec(request):
   s = Reg.objects.get(pk=request.POST["txtid"])    
   s.username = request.POST["txtuser"]  
   s.password = request.POST["txtpass"]
   s.role = request.POST["txtrole"]
   s.fname = request.POST["txtfname"]
   s.save()
   return redirect('dashboard')

def findrec1(request):
     s = Reg.objects.get(pk=request.GET["q"])
     return render(request,"hrapp/findrec1.html",{'data':s})
def deleterec(request):
     s = Reg.objects.get(pk=request.POST["txtid"])
     s.delete()
     return redirect('dashboard')

def logout(request):
    del request.session["uid"]
    return redirect('/')     