from django.apps import AppConfig


class HrappConfig(AppConfig):
    name = 'hrapp'
