from django.shortcuts import render
from django.http import HttpResponse
from hrapp.models import Reg
def index(request):
    if request.method=="POST":
        obj = Reg.objects.filter(username=request.POST["txtuser"],password=request.POST["txtpass"],role='manager')
        if obj.count()>0:
            return HttpResponse("Login Success")
        else:
           return HttpResponse("Invalid Userid and Password")
    return render(request,"managerapp/index.html")
def about(request):
	return render(request,"managerapp/about.html")
def contact(request):
	return render(request,"managerapp/contact.html")

def dashboard(request):
	return render(request,"managerapp/dashboard.html")		