from django.db import models

class Reg(models.Model):
   username = models.IntegerField()
   password =  models.CharField(max_length=50)
   role     =     models.CharField(max_length=50)
   fname    =    models.CharField(max_length=50)
   email    =     models.CharField(max_length=100, default='')
   def __str__(self):
      return "username is "+str(self.username) + " password is "+self.password + "role "+self.role+ "name is "+str(self.fname)

class Feedback(models.Model):
    feedto = models.CharField(max_length=50)
    feedby = models.CharField(max_length=50)
    rating = models.IntegerField(max_length=50)
    fdesc = models.CharField(max_length=50,default='')
    def __str__(self):
       return "Feed to"+str(self.feedto) +  " Feed By" + self.feedby + "rating" + str(self.rating)   