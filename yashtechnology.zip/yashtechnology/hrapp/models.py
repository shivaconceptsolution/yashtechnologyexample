from django.db import models

class Reg(models.Model):
   username = models.IntegerField()
   password= models.CharField(max_length=50)
   role = models.CharField(max_length=50)
   fname = models.CharField(max_length=50)
   email=models.CharField(max_length=100, default='')
   def __str__(self):
      return "username is "+str(self.username) + " password is "+self.password + "role "+self.role+ "name is "+str(self.fname)