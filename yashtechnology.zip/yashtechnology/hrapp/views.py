from django.shortcuts import render,redirect
from .models import Reg
from django.http import HttpResponse

def index(request):
    if request.method=="POST":
        obj = Reg(username=request.POST["txtuser"],password=request.POST["txtpass"],role=request.POST["txtrole"],fname=request.POST["txtfname"])
        obj.save()
        return render(request,"hrapp/index.html",{"key":'reg successfully'})
    return render(request,"hrapp/index.html")

def loginlogic(request):
     obj = Reg.objects.filter(username=request.POST["txtu"],password=request.POST['txtp'])
     if obj.count()>0:
        return redirect('dashboard')
     else:
         return HttpResponse("Login not successfully")   
def about(request):
	return render(request,"hrapp/about.html")

def contact(request):
	return render(request,"hrapp/contact.html")

def dashboard(request):
     res = Reg.objects.all()
     return render(request,"hrapp/dashboard.html",{'data':res})
