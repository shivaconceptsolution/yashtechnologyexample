from django.urls import path

from. import views

urlpatterns = [

    path('', views.index, name='index'),
    path('loginlogic', views.loginlogic, name='loginlogic'),
    path('reglogic', views.reglogic, name='reglogic'),
    path('dashboard', views.dashboard, name='dashboard'),
    path('logout', views.logout, name='logout')
]