from django.shortcuts import render,redirect
from django.http import HttpResponse
from hrapp.models import Reg,Feedback
def index(request):
    if request.method=="POST":
        obj = Reg.objects.filter(username=request.POST["txtuser"],password=request.POST["txtpass"]).exclude(role='hr').values('role')
        if obj.count()>0:
            request.session["dept"]= obj[0]['role']
            return redirect('dashboard')
        else:
           return HttpResponse("Invalid Userid and Password")
    return render(request,"managerapp/index.html")
def about(request):
	return render(request,"managerapp/about.html")
def contact(request):
	return render(request,"managerapp/contact.html")

def dashboard(request):
    f = Feedback.objects.filter(feedto=request.session["dept"])
    return render(request,"managerapp/dashboard.html",{'res':f,'dept':request.session["dept"]})
def reply(request):
    return render(request,"managerapp/reply.html")
def logout(request):
    return redirect('/manager')
